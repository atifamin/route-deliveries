<?php
$seg1 = $this->uri->segment("1");
$seg2 = $this->uri->segment("2");
$seg3 = $this->uri->segment("3");
?>

<div class="page-header-menu">
  <div class="container">
    <div class="hor-menu  ">
      <ul class="nav navbar-nav">
        <li aria-haspopup="true" class="menu-dropdown classic-menu-dropdown <?php if($seg1==TRUE && $seg2=="dashboard"){echo "active";} ?>"> <a href="<?php echo site_url("router/dashboard"); ?>"> Dashboard <span class="arrow"></span> </a> </li>
        <li aria-haspopup="true" class="menu-dropdown classic-menu-dropdown <?php if($seg1==TRUE && $seg2=="current_orders"){echo "active";} ?>"> <a href="<?php echo site_url("router/current_orders"); ?>"> Orders <span class="arrow"></span> </a> </li>
        <li aria-haspopup="true" class="menu-dropdown classic-menu-dropdown <?php if($seg1==TRUE && ($seg2=="my_orders" || $seg2=="order_history")){echo "active";} ?>"> <a href="javascript:;"> My Orders <span class="arrow"></span> </a>
          <ul class="dropdown-menu pull-left">
            <li aria-haspopup="true" class="menu-dropdown classic-menu-dropdown <?php if($seg1==TRUE && $seg2=="my_orders"){echo "active";} ?>"> <a href="<?php echo site_url("router/my_orders"); ?>"> Current Orders <span class="arrow"></span> </a> </li>
            <li aria-haspopup="true" class="menu-dropdown classic-menu-dropdown <?php if($seg1==TRUE && $seg2=="order_history"){echo "active";} ?>"> <a href="<?php echo site_url("router/order_history"); ?>"> Order History <span class="arrow"></span> </a> </li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</div>
