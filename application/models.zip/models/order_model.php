<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Order_Model extends CI_Model{
	
	public function unassigned_orders(){
		$this->db->where("status", "Active");
		return $this->db->get("orders");
	}
	
	//asssign order to the router
	public function order_assigned($user_id, $status, $order_id){
		$this->db->set("assigned_router", $user_id);
		$this->db->set("status", $status);
		$this->db->where("id", $order_id);
		$this->db->update("orders");
		return TRUE;
	}
	
	//router active orders
	public function router_active_orders(){
		$user = $this->session->userdata("user_session");
		$user_id = $user->id;
		$query = $this->db->query("SELECT * FROM orders WHERE orders.assigned_router = $user_id AND orders.`status` <> 'Delivered'");
		return $query;
	}
	
	//get order by id
	public function get_order_byID($id){
		$this->db->where("id", $id);
		$query = $this->db->get("orders");
		return $query->row();
	}
	
	//change status of order
	public function change_status($id, $status){
		$this->db->set("status", $status);
		$this->db->where("id", $id);
		$this->db->update("orders");
		return TRUE;
	}
	
		
}