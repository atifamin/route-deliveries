<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Client_Model extends CI_Model{
	
	//client signup
	public function client_signup($first, $last, $email, $password, $phone, $city){
		$this->db->where("Email", $email);
		$query1 = $this->db->get("users");
		if($query1->num_rows()>0){
			return FALSE;
		}else{
			$data = array(
					"user_type" => "3",
					"First_Name" => $first,
					"Last_Name" => $last,
					"Email" => $email,
					"Password" => $password,
					"Phone" => $phone,
					"City" => $city,
				);
			$this->db->insert("users", $data);
			return TRUE;
		}
	}
	
	//view all orders by user
	public function all_current_orders(){
		$user = $this->session->userdata("user_session");
		$user_type = $user->user_type;
		$user_id = $user->id;
		if($user_type=="3"){
			$query = $this->db->query('SELECT * FROM orders WHERE orders.user_id = '.$user_id.' AND orders.`status` <> "Delivered"');
			return $query;
		}else{
			$this->db->query('SELECT * FROM orders');
			return $this->db->get();
		}
	}
	
	//client old model
	public function client_old_orders($user_id){
		$this->db->where("user_id", $user_id);
		$this->db->where("status", "Delivered");
		return $this->db->get("orders");
	}
	
	//getting order by id
	public function get_order($order_id){
		$this->db->select("o.id, o.user_id, o.user_type, o.order_distance, o.date, o.assigned_router, o.order_payment, o.pickup_place, o.pickup_address, o.pickup_items, o.pickup_instructions, o.dropoff_place, o.dropoff_address, o.dropoff_items, o.dropoff_instructions, o.status, o.paypall_response, o.payment_method, u.user_type, u.First_Name, u.Last_Name, u.Email, u.Password, u.Phone, u.City, u.Image, u.`Status` as user_status");
		$this->db->from("orders AS o");
		$this->db->join("users AS u","u.id = o.assigned_router", "LEFT");
		$this->db->where("o.id", $order_id);
		$query = $this->db->get();
		return $query->row();
	}


		
}