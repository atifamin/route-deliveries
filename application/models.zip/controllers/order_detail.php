<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Order_Detail extends CI_Controller {
	
	public function __construct(){
		parent::__construct();
		if(!$this->session->userdata("user_session")){
			redirect();
		}
	}
	
	public function order($order_id){
		$data["order_detail"] = $this->Client_Model->get_order($order_id);
		$this->load->view('order_detail', $data);
	}
	
}
