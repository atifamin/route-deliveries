<?php include(APPPATH."views/web/includes/header1.php"); ?>
<style>
::-webkit-input-placeholder { /* Chrome/Opera/Safari */
 color: white !important;
}
		::-moz-placeholder { /* Firefox 19+ */
 color: white !important;
}
		:-ms-input-placeholder { /* IE 10+ */
 color: white !important;
}
		:-moz-placeholder { /* Firefox 18- */
 color: white !important;
}
.file {
	visibility: hidden;
	position: absolute;
}

.c-content-pricing-1 > .c-tile-container > .c-tile-small {
	margin: 40px 8px !important;
}
</style>
<?php include(APPPATH."views/web/includes/header2.php"); ?>
<?php if($this->session->flashdata("router_signup_success")){ ?>
<div class="alert alert-success alert-dismissible" role="alert" style="margin-bottom:0px !important;" align="center"> <?php echo $this->session->flashdata("router_signup_success"); ?>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
</div>
<?php } ?>
<?php if($this->session->flashdata("router_signup_failed")){ ?>
<div class="alert alert-danger alert-dismissible" role="alert" style="margin-bottom:0px !important;" align="center"> <?php echo $this->session->flashdata("router_signup_failed"); ?>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
</div>
<?php } ?>
<div class="c-content-box c-size-md c-no-padding c-bg-dark">
  <div class="c-content-feature-4">
    <div class="c-bg-parallax c-feature-bg c-content-left c-arrow c-border-right-dark" style="background-image: url(<?php echo base_url("assets/base/img/content/backgrounds/bg-51.jpg")?>)" align="center"> <span style="font-size:30px;color:white">Flexible hours. Be active.</span><br>
      <span style="font-size:60px;color:white"><strong>Meet great people around your city!</strong></span> </div>
    <div class="c-content-area c-content-right"></div>
    <div class="container">
      <div class="c-feature-content c-right" style="width:50% !important">
        <div class="c-content-v-center">
          <div class="c-wrapper">
            <div class="c-body">
              <div class="c-content-title-1 animated wow fadeInDown" data-wow-delay="0.2s">
                <h3 class="c-font-uppercase c-font-bold c-right c-font-white">Become a Router</h3>
              </div>
              <div class="c-content animated wow fadeInDown" data-wow-delay="0.7s">
                <form class="form-inline" action="<?php echo site_url("become_router/router_signup"); ?>" method="post" enctype="multipart/form-data">
                  <div class="col-md-12">
                    <div class="form-group" style="width:78% !important; margin:1% 0">
                      <input type="text" class="form-control c-bg-transparent input-lg c-theme c-square" name="first" style="color:white !important;" placeholder="First Name" required="required">
                      <input type="text" class="form-control c-bg-transparent input-lg c-theme c-square" name="last" style="color:white !important;" placeholder="Last Name" required="required">
                      <input type="email" class="form-control c-bg-transparent input-lg c-theme c-square" name="email" style="color:white !important;" placeholder="Email" required="required">
                    </div>
                    <div class="form-group" style="margin:1% 0">
                      <input type="text" class="form-control c-bg-transparent input-lg c-theme c-square" name="phone" style="color:white !important;" placeholder="Phone" required="required">
                      <input type="text" class="form-control c-bg-transparent input-lg c-theme c-square" name="city" style="color:white !important;" placeholder="City" required="required">
                    </div>
                    <div class="form-group" style="width:78% !important">
                      <input type="file" class="file" required="required" name="image">
                      <div class="input-group col-xs-12"> <span class="input-group-addon" style="border-color:white !important; color:white !important; background-color:transparent !important;"><i class="glyphicon glyphicon-picture"></i></span>
                        <input type="text" class="form-control input-lg" disabled placeholder="Upload Resume" style="background-color:transparent !important;color:white !important;">
                        <span class="input-group-btn">
                        <button class="browse btn btn-primary input-lg" type="button" style="border-color:white !important; color:white !important;background-color:transparent !important;"><i class="glyphicon glyphicon-search"></i> Select File</button>
                        </span> </div>
                    </div>
                  </div>
                  <div class="col-md-12" style="margin-top:6% !important">
                    <button type="submit" class="btn btn-lg btn-danger c-btn-uppercase c-btn-square c-btn-bold" style="padding: 12px 20px 11px 20px !important;">Send</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="c-content-box c-size-md c-bg-grey-1">
  <div class="container">
    <div class="c-content-pricing-1">
      <h1 style="padding:0 5% 0 5% !important"><strong>Become a ROUTER</strong></h1>
      <p style="padding:0 5% 0 5% !important">Be a part of something bigger in your community. Our team not only provides services to our clients, but also gives back to our community by contributing to Feed the Children Foundation.</p>
      <p style="padding:0 5% 0 5% !important">Our Routers earn $15-$25 on average/hour while enjoying the benefits of a workplace with flexible hours, and an upbeat, social-friendly environment..</p>
      <div class="c-tile-container">
        <div class="c-tile c-tile-small wow animate fadeInLeft" style="padding:50px 0 170px 0 !important;"> <span class="glyphicon glyphicon-usd" style="font-size:78px; color:#c82026"></span>
          <p class="c-price" style="font-size:30px !important">Your Compensation</p>
          <p style="width:60%; margin:0 auto;">You receive 100% of your tips. All scheduled hours have minimum guaranteed earnings, though most runners average between $10 to $18 per hour. </p>
        </div>
        <div class="c-tile c-tile-small wow animate fadeInUp" style="padding:50px 0 150px 0 !important;"> <span class="glyphicon glyphicon-time" style="font-size:78px; color:#c82026"></span>
          <p class="c-price" style="font-size:30px !important">Part Time & Full Time</p>
          <p style="width:60%; margin:0 auto;">Our Runner team is growing very fast and we have a lot of openings to fill. At Favor, we work around your schedule and you can even make cash by referring your friends to be runners. </p>
        </div>
        <div class="c-tile c-tile-small wow animate fadeInRight" style="padding:50px 0 170px 0 !important;"> <span class="glyphicon glyphicon-phone" style="font-size:78px; color:#c82026"></span>
          <p class="c-price" style="font-size:30px !important">A Few Requirements</p>
          <p style="width:60%; margin:0 auto;">At this time, you must have an iPhone or Android.You should own a car, bike, scooter or motorcycle and have a clean record.You must be 18 years or older to apply. </p>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- END: CONTENT/PRICING/PRICING-1 --> 
<!-- END: PAGE CONTENT -->
<?php include(APPPATH."views/web/includes/footer1.php"); ?>
<script type="text/javascript">

$(document).on('click', '.browse', function(){
  var file = $(this).parent().parent().parent().find('.file');
  file.trigger('click');
});
$(document).on('change', '.file', function(){
  $(this).parent().find('.form-control').val($(this).val().replace(/C:\\fakepath\\/i, ''));
});

</script>
<?php include(APPPATH."views/web/includes/footer2.php"); ?>
