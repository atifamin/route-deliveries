<?php include(APPPATH."views/admin/includes/header1.php"); ?>
<?php include(APPPATH."views/admin/includes/header2.php"); ?>
<?php include("includes/main_nav.php"); ?>
<?php include(APPPATH."views/admin/includes/header3.php"); ?>
<div class="row" style="margin-top:5%">
  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="page-content-inner">
      <div class="portlet light " align="center">
        <div class="portlet-body">
          <div class="tiles">
          <div class="col-md-3">
            <div class="tile bg-green-meadow">
              <div class="tile-body"> <i class="fa fa-shopping-cart"></i> </div>
              <div class="tile-object">
                <div class="name"> New Orders </div>
                <div class="number"> 12 </div>
              </div>
            </div>
            </div>
            <div class="col-md-3">
            <div class="tile bg-red-intense">
              <div class="tile-body"> <i class="fa fa-users"></i> </div>
              <div class="tile-object">
                <div class="name"> New Clients </div>
                <div class="number"> 45 </div>
              </div>
            </div>
            </div>
            <div class="col-md-3">
            <div class="tile bg-green">
              <div class="tile-body"> <i class="fa fa-star"></i> </div>
              <div class="tile-object">
                <div class="name"> Delivered </div>
                <div class="number"> 90% </div>
              </div>
            </div>
            </div>
            <div class="col-md-3">
            <div class="tile bg-blue-steel">
              <div class="tile-body"> <i class="fa fa-user"></i> </div>
              <div class="tile-object">
                <div class="name"> Drivers </div>
                <div class="number"> 15 </div>
              </div>
            </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include(APPPATH."views/admin/includes/footer1.php"); ?>
<?php include(APPPATH."views/admin/includes/footer2.php"); ?>
