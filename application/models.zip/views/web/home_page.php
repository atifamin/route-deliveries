<?php include(APPPATH."views/web/includes/header1.php"); ?>
<style>
::-webkit-input-placeholder { /* Chrome/Opera/Safari */
 color: white !important;
}
::-moz-placeholder { /* Firefox 19+ */
 color: white !important;
}
:-ms-input-placeholder { /* IE 10+ */
 color: white !important;
}
:-moz-placeholder { /* Firefox 18- */
 color: white !important;
}
.main_background {
	padding: 130px 0 !important;
}
.c-nav li a {
	font-size: 12px !important;
}
.input-lg {
	color: white !important;
	width: 300px !important;
}
.socicon-btn {
	background-color: white !important;
	color: #ab252b !important;
}
.scrolloff {
	pointer-events: none;
}
</style>
<?php include(APPPATH."views/web/includes/header2.php"); ?>
<?php if($this->session->flashdata("client_signup_success")){ ?>
<div class="alert alert-success alert-dismissible" role="alert" style="margin-bottom:0px !important;" align="center"> <?php echo $this->session->flashdata("client_signup_success"); ?>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
</div>
<?php } ?>
<?php if($this->session->flashdata("client_signup_failed")){ ?>
<div class="alert alert-danger alert-dismissible" role="alert" style="margin-bottom:0px !important;" align="center"> <?php echo $this->session->flashdata("client_signup_failed"); ?>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
</div>
<?php } ?>
<?php if($this->session->flashdata("please_login")){ ?>
<div class="alert alert-danger alert-dismissible" role="alert" style="margin-bottom:0px !important;" align="center"> <?php echo $this->session->flashdata("please_login"); ?>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
</div>
<?php } ?>
<div class="c-content-box c-size-md c-bg-img-top c-bg-parallax" style="background-image: url(<?php echo base_url("assets/base/img/content/backgrounds/main_background.jpg")?>)">
  <div class="container">
    <div class="c-content-feature-11">
      <div class="row">
        <div class="col-md-6 c-grid" data-auto-height="true" data-related="#c-video-card-3">
          <div class="c-singup-form">
            <h3 class="c-font-54 c-font-thin c-font-white c-margin-b-40 c-font-uppercase"> Any Pickup, <span class="c-theme-font c-font-bold">Any Delivery</span> </h3>
            <form class="form-inline" action="<?php echo base_url("create_order"); ?>" method="post" enctype="multipart/form-data">
              <div class="form-group">
                <input type="text" class="form-control c-bg-transparent input-lg c-theme c-square controls" placeholder="Pickup Location" id="us5-address" name="pickup" required="required" style="color:white !important;">
                <input type="hidden" class="form-control" style="width: 110px;" id="us5-lat" name="pickup_lat" />
                <input type="hidden" class="form-control" style="width: 110px;" id="us5-lon" name="pickup_lon" />
                <div id="us5" style="width: 420px; height: 400px; display:none"></div>
              </div>
              <div class="form-group">
                <input type="text" class="form-control c-bg-transparent input-lg c-theme c-square " placeholder="Drop Off Location" id="us6-address" name="dropoff" required="required" style="color:white !important;">
                <input type="hidden" class="form-control" style="width: 110px;" id="us6-lat" name="dropoff_lat" />
                <input type="hidden" class="form-control" style="width: 110px;" id="us6-lon" name="dropoff_lon" />
                <div id="us6" style="width: 420px; height: 400px; display:none"></div>
              </div>
              <button type="submit" class="btn btn-lg btn-danger c-btn-uppercase c-btn-square c-btn-bold" style="margin-top:2%">Let's Route</button>
            </form>
          </div>
        </div>
        <div class="col-md-6 "> <img src="<?php echo base_url("assets/base/img/content/backgrounds/pull_down_screen.png")?>" style="width:45%; position:absolute" class="img-responsive" /> </div>
      </div>
    </div>
  </div>
</div>
<!--<div class="c-content-box c-size-md c-bg-img-top c-bg-parallax main_background" style="background-image: url(assets/base/img/content/backgrounds/main_background.jpg)">
  <div class="container" style="padding:6% 0">
    <div class="c-content-feature-11"   style="padding:2% 0">
      <div class="row" align="center">
        <div class="c-singup-form">
          <h3 class="c-font-54 c-font-thin c-font-white c-margin-b-40 c-font-uppercase"> Any Pickup, <span class="c-theme-font c-font-bold">Any Delivery</span> </h3>
          <form class="form-inline" action="<?php echo base_url("create_order"); ?>" method="post" enctype="multipart/form-data">
            <div class="form-group">
              <input type="text" class="form-control c-bg-transparent input-lg c-theme c-square controls" placeholder="Pickup Location" id="us5-address" name="pickup">
              <input type="hidden" class="form-control" style="width: 110px;" id="us5-lat" name="pickup_lat" />
              <input type="hidden" class="form-control" style="width: 110px;" id="us5-lon" name="pickup_lon" />
              <div id="us5" style="width: 420px; height: 400px; display:none"></div>
            </div>
            <div class="form-group">
              <input type="text" class="form-control c-bg-transparent input-lg c-theme c-square " placeholder="Drop Off Location" id="us6-address" name="dropoff">
              <input type="hidden" class="form-control" style="width: 110px;" id="us6-lat" name="dropoff_lat" />
              <input type="hidden" class="form-control" style="width: 110px;" id="us6-lon" name="dropoff_lon" />
              <div id="us6" style="width: 420px; height: 400px; display:none"></div>
            </div>
            <button type="submit" class="btn btn-lg btn-danger c-btn-uppercase c-btn-square c-btn-bold">Let's Route</button>
          </form>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-12" align="center">
    <div class="c-video" style="width:36%" align="center">
      <div id="c-video-card-3" class="embed-responsive embed-responsive-16by9">
        <iframe class="embed-responsive-item" src="//www.youtube.com/embed/SDwGX3kWVYc?rel=0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
      </div>
    </div>
  </div>
</div>--> 
<!-- END: LAYOUT/SLIDERS/REVO-SLIDER-5 --> 
<!-- BEGIN: CONTENT/MISC/LATEST-ITEMS-1 -->
<div class="c-content-box c-size-md c-bg-img-top " >
  <div class="container">
    <div class="col-md-12" align="center">
      <div class="c-content-feature-11">
        <div class="c-video" style="width:50%" align="center">
          <div id="c-video-card-3" class="embed-responsive embed-responsive-16by9">
            <iframe class="embed-responsive-item" src="//www.youtube.com/embed/SDwGX3kWVYc?rel=0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="c-content-box c-size-md c-bg-white">
  <div class="container">
    <div class="c-content-client-logos-slider-1  c-bordered" data-slider="owl" data-items="6" data-desktop-items="4" data-desktop-small-items="3" data-tablet-items="3" data-mobile-small-items="2" data-auto-play="5000">
      <div class="c-content-title-1">
        <h3 class="c-center c-font-uppercase c-font-bold">What can i have delivered</h3>
        <div class="c-line-center c-theme-bg"></div>
      </div>
      <div class="owl-carousel owl-theme c-theme owl-bordered1">
        <div class="item"> <a href="#"> <img src="<?php echo base_url("assets/base/img/content/client-logos/pic-1.png")?>" alt="" class="img-responsive" /> </a> </div>
        <div class="item"> <a href="#"> <img src="<?php echo base_url("assets/base/img/content/client-logos/pic-2.png")?>" alt="" class="img-responsive" /> </a> </div>
        <div class="item"> <a href="#"> <img src="<?php echo base_url("assets/base/img/content/client-logos/pic-3.png")?>" alt="" class="img-responsive" /> </a> </div>
        <div class="item"> <a href="#"> <img src="<?php echo base_url("assets/base/img/content/client-logos/pic-4.jpg")?>" alt="" class="img-responsive" /> </a> </div>
        <div class="item"> <a href="#"> <img src="<?php echo base_url("assets/base/img/content/client-logos/pic-5.jpg")?>" alt="" class="img-responsive" /> </a> </div>
        <div class="item"> <a href="#"> <img src="<?php echo base_url("assets/base/img/content/client-logos/pic-6.jpg")?>" alt="" class="img-responsive" /> </a> </div>
        <!--<div class="item"> <a href="#"> <img src="<?php //echo base_url("assets/base/img/content/client-logos/client4.jpg")?>" alt="" class="img-responsive" /> </a> </div>
          <div class="item"> <a href="#"> <img src="<?php //echo base_url("assets/base/img/content/client-logos/client5.jpg")?>" alt="" class="img-responsive" /> </a> </div>
          <div class="item"> <a href="#"> <img src="<?php //echo base_url("assets/base/img/content/client-logos/client6.jpg")?>" alt="" class="img-responsive" /> </a> </div>
          <div class="item"> <a href="#"> <img src="<?php //echo base_url("assets/base/img/content/client-logos/client5.jpg")?>" alt="" class="img-responsive" /> </a> </div>
          <div class="item"> <a href="#"> <img src="<?php //echo base_url("assets/base/img/content/client-logos/client6.jpg")?>" alt="" class="img-responsive" /> </a> </div>
          <div class="item"> <a href="#"> <img src="<?php //echo base_url("assets/base/img/content/client-logos/client5.jpg")?>" alt="" class="img-responsive" /> </a> </div>
          <div class="item"> <a href="#"> <img src="<?php //echo base_url("assets/base/img/content/client-logos/client6.jpg")?>" alt="" class="img-responsive" /> </a> </div>
          <div class="item"> <a href="#"> <img src="<?php //echo base_url("assets/base/img/content/client-logos/client5.jpg")?>" alt="" class="img-responsive" /> </a> </div>
          <div class="item"> <a href="#"> <img src="<?php //echo base_url("assets/base/img/content/client-logos/client6.jpg")?>" alt="" class="img-responsive" /> </a> </div>--> 
      </div>
    </div>
  </div>
</div>
<div class="c-content-box c-size-md c-bg-img-top" style="background-image: url(<?php echo base_url("assets/base/img/content/backgrounds/bg-84.jpg")?>)">
  <div class="container" align="center" style="padding-left:2%">
    <div class="col-md-3"> <a href="#"> <img src="<?php echo base_url("assets/base/img/layout/logos/The_Boston_Globe.svg.png")?>" alt="" class="img-responsive" /> </a> </div>
    <div class="col-md-3" style="width:10%"> <a href="#"> <img src="<?php echo base_url("assets/base/img/layout/logos/cnbc_logo.png")?>" alt="" class="img-responsive" style="width:55%;"  /> </a> </div>
    <div class="col-md-3"> <a href="#"> <img src="<?php echo base_url("assets/base/img/layout/logos/The_New_York_Times_logo.png")?>" alt="" class="img-responsive"  /> </a> </div>
    <div class="col-md-3"> <a href="#"> <img src="<?php echo base_url("assets/base/img/layout/logos/WSJ_Logo.svg.png")?>" alt="" class="img-responsive"  /> </a> </div>
  </div>
</div>
<div class="c-content-box c-size-md c-bg-img-top c-no-padding c-pos-relative">
  <div class="container">
    <div class="c-content-contact-1 c-opt-1">
      <div class="row" data-auto-height=".c-height">
        <div class="col-sm-8 c-desktop"></div>
        <div class="col-sm-4">
          <div class="c-body">
            <div class="c-section">
              <h3 style="text-transform:none;">Hours & Routing Areas</h3>
            </div>
            <div class="c-section">
              <div class="c-content-label c-font-uppercase c-font-bold c-theme-bg">Areas</div>
              <p>Westwood, Los Angeles, CA, United States</p>
            </div>
            <div class="c-section">
              <div class="c-content-label c-font-uppercase c-font-bold c-theme-bg">Hours</div>
              <p> <strong>Sun-Wed</strong> 10:00AM - 9:00PM <br/>
                <strong>Thurs-Sat</strong> 10:00AM - 3:00AM 
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="c-content-contact-1-gmap" >
    <section id="canvas1" class="map">
      <iframe id="map_canvas1" frameborder="0" style="border:0; width:100% !important; height:500px !important" src="https://www.google.com/maps/embed/v1/place?q=place_id:ChIJecf92oa8woARVlNT9X_x42M&key=AIzaSyB817afzToi3HSAZPdCidje_ZArSfy2nic" allowfullscreen></iframe>
    </section>
    <!--<iframe frameborder="0" style="border:0; width:100% !important; height:100% !important" src="https://www.google.com/maps/embed/v1/place?q=place_id:ChIJP5iLHkCuEmsRwMwyFmh9AQU&key=AIzaSyB817afzToi3HSAZPdCidje_ZArSfy2nic" allowfullscreen></iframe>--> 
  </div>
</div>
<?php include(APPPATH."views/web/includes/footer1.php"); ?>
<script type="text/javascript" src='https://maps.google.com/maps/api/js?sensor=false&libraries=places&key=AIzaSyANGFXCJqEp3TUD6Ew6VLO_j9cuvSlk4qw'></script> 
<script src="<?php echo base_url("assets/base/js/dist/locationpicker.jquery.min.js")?>"></script> 
<!-- END: PAGE SCRIPTS --> 
<!-- END: LAYOUT/BASE/BOTTOM --> 
<script type="text/javascript">
	 $('#us5').locationpicker({
		
		location: {
			latitude: 0,
			longitude: 0
		},
		radius: 10,
		inputBinding: {
			latitudeInput: $('#us5-lat'),
			longitudeInput: $('#us5-lon'),
			radiusInput: $('#us5-radius'),
			locationNameInput: $('#us5-address')
		},
		enableAutocomplete: true,
		onchanged: function (currentLocation, radius, isMarkerDropped) {
			// Uncomment line below to show alert on each Location Changed event
			//alert("Location changed. New location (" + currentLocation.latitude + ", " + currentLocation.longitude + ")");
		}
	});
	
	
	$('#us6').locationpicker({
		location: {
			latitude: 0,
			longitude: 0
		},
		radius: 10,
		inputBinding: {
			latitudeInput: $('#us6-lat'),
			longitudeInput: $('#us6-lon'),
			radiusInput: $('#us6-radius'),
			locationNameInput: $('#us6-address')
		},
		enableAutocomplete: true,
		onchanged: function (currentLocation, radius, isMarkerDropped) {
			// Uncomment line below to show alert on each Location Changed event
			//alert("Location changed. New location (" + currentLocation.latitude + ", " + currentLocation.longitude + ")");
		}
	});
	
	$(document).ready(function () {

        // you want to enable the pointer events only on click;

        $('#map_canvas1').addClass('scrolloff'); // set the pointer events to none on doc ready
        $('#canvas1').on('click', function () {
            $('#map_canvas1').removeClass('scrolloff'); // set the pointer events true on click
        });

        // you want to disable pointer events when the mouse leave the canvas area;

        $("#map_canvas1").mouseleave(function () {
            $('#map_canvas1').addClass('scrolloff'); // set the pointer events to none when mouse leaves the map area
        });
    });

</script>
<?php include(APPPATH."views/web/includes/footer2.php"); ?>
