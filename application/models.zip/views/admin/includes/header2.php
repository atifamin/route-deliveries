</head>
<!-- END HEAD -->
<body class="page-container-bg-solid">
<div class="page-wrapper">
  <div class="page-wrapper-row">
    <div class="page-wrapper-top">
      <div class="page-header">
        <div class="page-header-top">
          <div class="container">
            <div class="page-logo"> <a href="<?php echo site_url(); ?>"> <img src="<?php echo base_url("assets/base/img/layout/logos/logo1.png")?>" alt="logo" class="logo-default" style="margin:13.5px 0 0 !important;"> </a> </div>
            <a href="javascript:;" class="menu-toggler"></a>
            <div class="top-menu">
              <ul class="nav navbar-nav pull-right">
                <li class="dropdown dropdown-user dropdown-dark"> <span></span> <a href="<?php echo site_url("dashboard/logout"); ?>"> <span class="username username-hide-mobile">Logout</span> </a> </li>
              </ul>
            </div>
          </div>
        </div>