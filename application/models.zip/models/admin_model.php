<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Admin_Model extends CI_Model{
	
	//view all clients to admin panel
	public function view_all_clients(){
		$this->db->where("user_type", "3");
		$this->db->order_by("id", "DESC");
		return $this->db->get("users");
	}
		
	public function all_drivers(){
		$this->db->where("user_type", "2");
		return $this->db->get("users");
	}
	
	public function get_driver($id){
		$this->db->where("id", $id);
		$query = $this->db->get("users");
		return $query->row();
	}
	
	public function delete_driver($id){
		$this->db->where("id", $id);
		$this->db->delete("users");
	}
	
	//load all current orders
	public function current_orders(){
		$query = $this->db->query("SELECT * FROM orders WHERE status <> 'Delivered'");
		return $query;
	}
	
	//load all completed orders
	public function order_history(){
		$query = $this->db->query("SELECT * FROM orders WHERE status = 'Delivered'");
		return $query;
	}
}