<?php include(APPPATH."views/admin/includes/header1.php"); ?>
<link href="<?php echo base_url("assets/admin/global/plugins/datatables/datatables.min.css")?>" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url("assets/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.css")?>" rel="stylesheet" type="text/css" />
<?php include(APPPATH."views/admin/includes/header2.php"); ?>
<?php include("includes/main_nav.php"); ?>
<?php include(APPPATH."views/admin/includes/header3.php"); ?>


<div class="row">
  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="row">
      <div class="col-md-12"> 
        <!-- BEGIN EXAMPLE TABLE PORTLET-->
        <div class="portlet light ">
          <div class="portlet-title">
            <div class="caption font-dark"> <i class="icon-settings font-dark"></i> <span class="caption-subject bold uppercase"> Clients Detail</span> </div>
          </div>
          <div class="portlet-body">
            <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
              <thead>
                <tr>
                  <th> ID </th>
                  <th> First Name </th>
                  <th> Last Name </th>
                  <th> Email </th>
                  <th> Address </th>
                </tr>
              </thead>
              <tbody>
              <?php if($clients->num_rows>0){ ?>
              <?php foreach($clients->result() as $clients){ ?>
                <tr class="odd gradeX">
                  <td> <?php echo $clients->id; ?> </td>
                  <td> <?php echo $clients->First_Name; ?> </td>
                  <td> <?php echo $clients->Last_Name; ?> </td>
                  <td> <?php echo $clients->Email; ?> </td>
                  <td> <?php echo $clients->City; ?> </td>
                </tr>
              <?php }} ?>
              </tbody>
            </table>
          </div>
        </div>
        <!-- END EXAMPLE TABLE PORTLET--> 
      </div>
    </div>
  </div>
</div>
<?php include(APPPATH."views/admin/includes/footer1.php"); ?>
<script src="<?php echo base_url("assets/admin/global/scripts/datatable.js")?>" type="text/javascript"></script> 
<script src="<?php echo base_url("assets/admin/global/plugins/datatables/datatables.min.js")?>" type="text/javascript"></script> 
<script src="<?php echo base_url("assets/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js")?>" type="text/javascript"></script> 
<script src="<?php echo base_url("assets/admin/pages/scripts/table-datatables-managed.min.js"); ?>" type="text/javascript"></script> 
<script src="<?php echo base_url("assets/admin/pages/scripts/ui-modals.min.js")?>" type="text/javascript"></script>
<?php include(APPPATH."views/admin/includes/footer2.php"); ?>
