<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Auth_Model extends CI_Model{
	
	public function authorization($email, $password){
		$this->db->where("Email", $email);
		$this->db->where("Password", $password);
		return $this->db->get("users");
	}
	
	public function user_session($email){
		$this->db->where("Email", $email);
		$query = $this->db->get("users");
		return $query->row();
	}
	
}