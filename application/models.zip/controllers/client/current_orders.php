<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Current_Orders extends CI_Controller {
	
	public function __construct(){
		parent::__construct();
		$user = $this->session->userdata("user_session");
		$user_type = $user->user_type;
		if($user_type!="3"){
			redirect();
		}
	}
	
	public function index(){
		$data["order_detail"] = $this->Client_Model->all_current_orders();
		$this->load->view('admin/client/current_orders', $data);
	}
		
	public function get_order(){
		$order_id = $this->input->post("order_id");
		$data["order_detail"] = $this->Client_Model->get_order($order_id);
		$this->load->view("admin/client/current_order_status", $data);
	}
	
}