</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="page-wrapper-row">
    <div class="page-wrapper-bottom">
      <div class="page-footer" style="background-color:#aa242a !important;color:white !important">
        <div class="container"> <a target="_blank" href="<?php echo site_url("terms"); ?>">Privacy Policy</a> &nbsp;|&nbsp; <a href="<?php echo site_url("privacy"); ?>" title="Purchase Metronic just for 27$ and get lifetime updates for free" target="_blank">Terms of Services</a> </div>
      </div>
      <div class="scroll-to-top"> <i class="icon-arrow-up"></i> </div>
    </div>
  </div>
</div>
<div class="quick-nav-overlay"></div>
<!-- BEGIN CORE PLUGINS --> 
<script src="<?php echo base_url("assets/admin/global/plugins/jquery.min.js")?>" type="text/javascript"></script> 
<script src="<?php echo base_url("assets/admin/global/plugins/bootstrap/js/bootstrap.min.js")?>" type="text/javascript"></script> 
<script src="<?php echo base_url("assets/admin/global/plugins/js.cookie.min.js")?>" type="text/javascript"></script> 
<script src="<?php echo base_url("assets/admin/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js")?>" type="text/javascript"></script> 
<script src="<?php echo base_url("assets/admin/global/plugins/jquery.blockui.min.js")?>" type="text/javascript"></script> 
<script src="<?php echo base_url("assets/admin/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js")?>" type="text/javascript"></script> 
<!-- END CORE PLUGINS --> 
<!-- BEGIN PAGE LEVEL PLUGINS --> 
<script src="<?php echo base_url("assets/admin/global/plugins/morris/morris.min.js")?>" type="text/javascript"></script> 
<script src="<?php echo base_url("assets/admin/global/plugins/morris/raphael-min.js")?>" type="text/javascript"></script> 
<script src="<?php echo base_url("assets/admin/global/plugins/horizontal-timeline/horizontal-timeline.js")?>" type="text/javascript"></script> 
<!-- END PAGE LEVEL PLUGINS --> 
<!-- BEGIN THEME GLOBAL SCRIPTS --> 
<script src="<?php echo base_url("assets/admin/global/scripts/app.min.js")?>" type="text/javascript"></script> 
<!-- END THEME GLOBAL SCRIPTS --> 
<!-- BEGIN PAGE LEVEL SCRIPTS --> 
<script src="<?php echo base_url("assets/admin/pages/scripts/dashboard.min.js")?>" type="text/javascript"></script> 
<!-- END PAGE LEVEL SCRIPTS --> 
<!-- BEGIN THEME LAYOUT SCRIPTS --> 
<script src="<?php echo base_url("assets/admin/global/scripts/datatable.js")?>" type="text/javascript"></script> 
<script src="<?php echo base_url("assets/admin/global/plugins/datatables/datatables.min.js")?>" type="text/javascript"></script> 
<script src="<?php echo base_url("assets/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js")?>" type="text/javascript"></script> 
<script src="<?php echo base_url("assets/admin/pages/scripts/table-datatables-managed.min.js"); ?>" type="text/javascript"></script> 
<script src="<?php echo base_url("assets/admin/pages/scripts/ui-modals.min.js")?>" type="text/javascript"></script>
<script src="<?php echo base_url("assets/admin/layouts/layout3/scripts/layout.min.js")?>" type="text/javascript"></script> 
<script src="<?php echo base_url("assets/admin/layouts/layout3/scripts/demo.min.js")?>" type="text/javascript"></script> 
<script src="<?php echo base_url("assets/admin/layouts/global/scripts/quick-sidebar.min.js")?>" type="text/javascript"></script> 
<script src="<?php echo base_url("assets/admin/layouts/global/scripts/quick-nav.min.js")?>" type="text/javascript"></script> 
<script src="<?php echo base_url("assets/admin/pages/scripts/form-validation.min.js")?>" type="text/javascript"></script>
<script src="<?php echo base_url("assets/admin/global/plugins/select2/js/select2.full.min.js")?>" type="text/javascript"></script>
<script src="<?php echo base_url("assets/admin/global/plugins/jquery-validation/js/jquery.validate.min.js")?>" type="text/javascript"></script>
<script src="<?php echo base_url("assets/admin/global/plugins/jquery-validation/js/additional-methods.min.js")?>" type="text/javascript"></script>
<script src="<?php echo base_url("assets/admin/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js")?>" type="text/javascript"></script>
<script src="<?php echo base_url("assets/admin/global/plugins/bootstrap-wysihtml5/wysihtml5-0.3.0.js")?>" type="text/javascript"></script>
<script src="<?php echo base_url("assets/admin/global/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.js")?>" type="text/javascript"></script>
<script src="<?php echo base_url("assets/admin/global/plugins/ckeditor/ckeditor.js")?>" type="text/javascript"></script>
<script src="<?php echo base_url("assets/admin/global/plugins/bootstrap-markdown/lib/markdown.js")?>" type="text/javascript"></script>
<script src="<?php echo base_url("assets/admin/global/plugins/bootstrap-markdown/js/bootstrap-markdown.js")?>" type="text/javascript"></script>
<!-- END THEME LAYOUT SCRIPTS -->