<?php include(APPPATH."views/admin/includes/header1.php"); ?>
<?php include(APPPATH."views/admin/includes/header2.php"); ?>
<?php include("includes/main_nav.php"); ?>
<?php include(APPPATH."views/admin/includes/header3.php"); ?>
<div class="row" style="margin-top:5%">
  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="page-content-inner">
      <div class="portlet light " align="center">
        <div class="portlet-body">
          <div class="tiles">
          <div class="col-md-3">
            <div class="tile bg-green-meadow">
              <div class="tile-body"> <img src="http://localhost/vp/route2/assets/admin/img/order_recieved1.png" width="50"> </div>
              <div class="tile-object">
                <div class="name"> Total Order Recevied </div><br />
                <div class="number"> 12 </div>
              </div>
            </div>
            </div>
            <div class="col-md-3">
            <div class="tile bg-red-intense">
              <div class="tile-body"> <img src="http://localhost/vp/route2/assets/admin/img/picked_up1.png" width="70"> </div>
              <div class="tile-object">
                <div class="name"> Total Orders Picked Up </div>
                <div class="number"> 45 </div>
              </div>
            </div>
            </div>
            <div class="col-md-3">
            <div class="tile bg-green">
              <div class="tile-body"> <img src="http://localhost/vp/route2/assets/admin/img/on_route1.png" width="50"> </div>
              <div class="tile-object">
                <div class="name"> Total Orders On Route </div>
                <div class="number"> 3 </div>
              </div>
            </div>
            </div>
            <div class="col-md-3">
            <div class="tile bg-blue-steel">
              <div class="tile-body"> <img src="http://localhost/vp/route2/assets/admin/img/deliver1.png" width="50"> </div>
              <div class="tile-object">
                <div class="name"> Total Orders Delivered </div>
                <div class="number"> 30 </div>
              </div>
            </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include(APPPATH."views/admin/includes/footer1.php"); ?>
<?php include(APPPATH."views/admin/includes/footer2.php"); ?>
