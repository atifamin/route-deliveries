<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Router_Signup_Model extends CI_Model{
	
	public function router_signup($first, $last, $email, $phone, $city, $imgname){
		$this->db->where("Email", $email);
		$query1 = $this->db->get("users");
		if($query1->num_rows()>0){
			return FALSE;
		}else{
			$data = array(
					"user_type" => "2",
					"First_Name" => $first,
					"Last_Name" => $last,
					"Email" => $email,
					"Phone" => $phone,
					"City" => $city,
					"Image" => $imgname,
				);
			$this->db->insert("users", $data);
			return TRUE;
		}
	}
	
	public function view_old_orders(){
		$user = $this->session->userdata("user_session");
		$user_id = $user->id;
		$this->db->where("assigned_router", $user_id);
		$this->db->where("status", "Delivered");
		return $this->db->get("orders");
	}
	
	public function change_status($id, $status){
		$this->db->set("Status", $status);
		$this->db->where("id", $id);
		$this->db->update("users");
		return TRUE;
	}
	
	public function assign_password($id, $first, $last, $email, $phone, $city, $password){
		$this->db->set("First_Name", $first);
		$this->db->set("Last_Name", $last);
		$this->db->set("Email", $email);
		$this->db->set("Phone", $phone);
		$this->db->set("City", $city);
		$this->db->set("Password", $password);
		$this->db->where("id", $id);
		$this->db->update("users");
		return TRUE;
	}
	
		
}