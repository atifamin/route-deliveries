</head>
<body class="c-layout-header-fixed c-layout-header-mobile-fixed">
<?php include(APPPATH."views/web/includes/nav.php"); ?>
<?php include(APPPATH."views/web/includes/login.php"); ?>
<div class="c-layout-page"> 
  <!-- BEGIN: PAGE CONTENT --> 