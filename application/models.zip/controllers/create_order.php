<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Create_Order extends CI_Controller {
	
	function  __construct() {
		parent::__construct();
		$this->load->library('paypal_lib');
	}
	
	public function index(){
		$data["pickup_lat"] = $this->input->post("pickup_lat");
		$data["pickup_lon"] = $this->input->post("pickup_lon");
		$data["dropoff_lat"] = $this->input->post("dropoff_lat");
		$data["dropoff_lon"] = $this->input->post("dropoff_lon");
		$this->load->view('web/create_order', $data);
	}
	
	public function create_new(){
		
		$user = $this->session->userdata("user_session");
		$user_id = $user->id;
		$user_type = $user->user_type;
		if(!empty($user_id)){
			
			//getting latitude and logitude
			$pickup_lat = $this->input->post("pickup_lat");
			$pickup_lon = $this->input->post("pickup_lon");
			$dropoff_lat = $this->input->post("dropoff_lat");
			$dropoff_lon = $this->input->post("dropoff_lon");
			
			//getting distances from latitude and logitude
			$order_distance = $this->haversineGreatCircleDistance($pickup_lat, $pickup_lon, $dropoff_lat, $dropoff_lon);
			
			//claculating amount from distance
			$order_payment = $order_distance * 12;
			
			//getting order details
			$pickup_place = $this->input->post("pickup_place");
			$pickup_address = $this->input->post("pickup_address");
			$pickup_items = $this->input->post("pickup_items");
			$pickup_instructions = $this->input->post("pickup_instructions");
			$dropoff_place = $this->input->post("dropoff_place");
			$dropoff_address = $this->input->post("dropoff_address");
			$dropoff_items = $this->input->post("dropoff_items");
			$dropoff_instructions = $this->input->post("dropoff_instructions");
			
			//making an array to add order in the database
			$order_data = array(
					"user_id" => $user_id,
					"user_type" => $user_type,
					"order_distance" => $order_distance,
					"date" => date("Y-m-d H:i:s"),
					"assigned_router" => '0',
					"order_payment" => $order_payment,
					"pickup_place" => $pickup_place,
					"pickup_address" => $pickup_address,
					"pickup_items" => $pickup_items,
					"pickup_instructions" => $pickup_instructions,
					"dropoff_place" => $dropoff_place,
					"dropoff_address" => $dropoff_address,
					"dropoff_items" => $dropoff_items,
					"dropoff_instructions" => $dropoff_instructions,
					"status" => 'Pending',
					"payment_method" => 'Paypal',
				);
			
			$data["order_detail"] = $this->Create_Order_Model->create_new($order_data);
			//echo "<pre>"; print_r($data["order_detail"]); exit;
			
			$this->load->view("web/order_confirm", $data);
			
			//echo "<pre>"; print_r($data); exit;
			//$this->buy();
		
			//echo "<pre>"; print_r($data); exit;
			
		}else{
			$this->session->set_flashdata("please_login", "Please Login OR Create an account to Route");
			redirect();
		}
		
		
		
		//$this->Create_Order_Model->create_new($user_id, $user_type, $order_distance);
	}
	
	public function haversineGreatCircleDistance($latitudeFrom, $longitudeFrom, $latitudeTo, $longitudeTo){
		  // convert from degrees to radians 
		  $earthRadius = 6371000;
		  $latFrom = deg2rad($latitudeFrom);
		  $lonFrom = deg2rad($longitudeFrom);
		  $latTo = deg2rad($latitudeTo);
		  $lonTo = deg2rad($longitudeTo);
		  
		  $latDelta = $latTo - $latFrom;
		  $lonDelta = $lonTo - $lonFrom;
		  
		  $angle = 2 * asin(sqrt(pow(sin($latDelta / 2), 2) + cos($latFrom)*cos($latTo)*pow(sin($lonDelta / 2), 2)));
		  $final = $angle * $earthRadius;
		  $final = $final/1000;
		  return $final;
	 }
	 	 
	
	public function confirm($order_id){
		//echo $order_id; exit;
		//Set variables for paypal form
		$returnURL = base_url().'paypal/success'; //payment success url
		$cancelURL = base_url().'paypal/cancel'; //payment cancel url
		$notifyURL = base_url().'paypal/ipn'; //ipn url
		//get particular product data
		//$product = $this->product->getRows($id);
		//getting order detail
		$data = $this->Create_Order_Model->order_by_id($order_id);
		//$userID = 1; //current user id 
		$logo = base_url().'assets/base/img/layout/logos/logo.png';
		
		$this->paypal_lib->add_field('return', $returnURL);
		$this->paypal_lib->add_field('cancel_return', $cancelURL);
		$this->paypal_lib->add_field('notify_url', $notifyURL);
		//$this->paypal_lib->add_field('item_name', $product['name']);
		$this->paypal_lib->add_field('custom', $data->id);
		//$this->paypal_lib->add_field('item_number',  $product['id']);
		$this->paypal_lib->add_field('amount',  $data->order_payment);		
		$this->paypal_lib->image($logo);
		
		$this->paypal_lib->paypal_auto_form();
	}
	
	
	//creating session for input fields of create order form
	public function store_input_values(){
		$data["pickup_lat"] = $this->input->post("pickup_lat");
		$data["pickup_lon"] = $this->input->post("pickup_lon");
		$data["pickup_place"] = $this->input->post("pickup_place");
		$data["pickup_address"] = $this->input->post("pickup_address");
		$data["pickup_items"] = $this->input->post("pickup_items");
		$data["pickup_instructions"] = $this->input->post("pickup_instructions");
		
		$data["dropoff_lat"] = $this->input->post("dropoff_lat");
		$data["dropoff_lon"] = $this->input->post("dropoff_lon");
		$data["dropoff_place"] = $this->input->post("dropoff_place");
		$data["dropoff_address"] = $this->input->post("dropoff_address");
		$data["dropoff_items"] = $this->input->post("dropoff_items");
		$data["dropoff_instructions"] = $this->input->post("dropoff_instructions");
		$this->session->set_userdata("user_input_val", $data);
		echo "Created";
	}
	
	
}
