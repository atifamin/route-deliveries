<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Become_Router extends CI_Controller {
	
	public function __construct(){
		parent::__construct();
	}
	
	public function index(){
		$this->load->view('web/become_router');
	}
	
	public function router_signup(){
		
		$first = $this->input->post("first");
		$last = $this->input->post("last");
		$email = $this->input->post("email");
		$phone = $this->input->post("phone");
		$city = $this->input->post("city");
		
		$imgname = $_FILES['image']['name'];
			$uploaddir = "./assets/base/uploads/";
			$uploadfile = $uploaddir.$imgname;
			if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadfile)){
			   $image = $fname;
		}
		
		$status = $this->Router_Signup_Model->router_signup($first, $last, $email, $phone, $city, $imgname);
		
		if($status){
			$this->session->set_flashdata("router_signup_success", "Thank you for registering as a router with us, We'll contact you soon.");
			redirect("become_router");
		}else{
			$this->session->set_flashdata("router_signup_failed", "This email is already registered with us.");
			redirect("become_router");
		}
	}
	
	public function assign_password($id){
		$first = $this->input->post("first");
		$last = $this->input->post("last");
		$email = $this->input->post("email");
		$phone = $this->input->post("phone");
		$city = $this->input->post("city");
		$password = md5(utf8_encode($this->input->post("password")));
		
		$status = $this->Router_Signup_Model->assign_password($id, $first, $last, $email, $phone, $city, $password);
		if($status){
			$this->session->set_flashdata("router_edit_success", "You have Updated Router Successfully!");
			redirect("admin1/drivers/all_drivers");
		}
	}
	
	public function change_status(){
		$id = $this->input->post("id");
		$status = $this->input->post("status");
		$status = $this->Router_Signup_Model->change_status($id, $status);
		if($status){
			echo "Status Changed";
		}
	}
	
	
}
