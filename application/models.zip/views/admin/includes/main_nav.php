<div class="page-header-menu">
          <div class="container">
            <div class="hor-menu  ">
              <ul class="nav navbar-nav">
                <li aria-haspopup="true" class="menu-dropdown classic-menu-dropdown active"> <a href="javascript:;"> Dashboard <span class="arrow"></span> </a>
                  <ul class="dropdown-menu pull-left">
                    <li aria-haspopup="true" class=" "> <a href="index.html" class="nav-link  "> Default Dashboard </a> </li>
                    <li aria-haspopup="true" class=" active"> <a href="dashboard_2.html" class="nav-link  active"> Dashboard 2 </a> </li>
                    <li aria-haspopup="true" class=" "> <a href="dashboard_3.html" class="nav-link  "> Dashboard 3 </a> </li>
                  </ul>
                </li>
                <li aria-haspopup="true" class="menu-dropdown classic-menu-dropdown"> <a href="javascript:;"> Page <span class="arrow"></span> </a> </li>
              </ul>
            </div>
          </div>
        </div>