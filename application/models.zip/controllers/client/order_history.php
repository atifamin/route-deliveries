<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Order_History extends CI_Controller {
	
	public function __construct(){
		parent::__construct();
		$user = $this->session->userdata("user_session");
		$user_type = $user->user_type;
		if($user_type!="3"){
			redirect();
		}
	}
	
	public function index(){
		$user = $this->session->userdata("user_session");
		$user_id = $user->id;
		$data["orders"] = $this->Client_Model->client_old_orders($user_id);
		$this->load->view('admin/client/order_history', $data);
	}
	
	public function get_order(){
		$order_id = $this->input->post("order_id");
		$data["order_detail"] = $this->Client_Model->get_order($order_id);
		$this->load->view("admin/client/history_order_status", $data);
	}
	
}
